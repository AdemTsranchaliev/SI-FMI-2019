#pragma once


enum SeriousOfProblem
{
	Low,
	Average,
	High
};